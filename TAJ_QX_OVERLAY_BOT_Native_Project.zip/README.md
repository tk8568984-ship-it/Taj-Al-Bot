# TAJ QX OVERLAY BOT — Native Android Trading Assistant

## Build APK in Terminal / VS Code:
```bash
# On Windows:
gradlew.bat assembleDebug

# On Linux / macOS:
./gradlew assembleDebug
```

APK output location:
`app/build/outputs/apk/debug/app-debug.apk`
